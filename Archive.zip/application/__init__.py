from flask import Flask
from flask import Flask


application = Flask(__name__)

from application import routes